<?php include $this->admin_tpl("header"); ?>
<div class="content">
    <div class="site">
        Haidao Board <a href="#">商品管理</a> > <?php echo $nav_title;?>
    </div>
    <?php include $modfile; ?>
    <?php include $this->admin_tpl('copyright') ?>
