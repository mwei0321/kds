
<div class="copy"><span class="line_white"></span>Powered by Haidao <?php echo getconfig('version'); ?> 版权所有 © 2013-2015 迪米盒子科技有限公司，并保留所有权利。</div></body></html>