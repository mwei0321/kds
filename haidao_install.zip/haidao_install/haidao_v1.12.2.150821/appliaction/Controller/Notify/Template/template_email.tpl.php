<div class="edit_box"> 
     <strong class="edit">您正在编辑邮件模版，默认所见即所得模式，您也可以点击HTML源码切换到代码模式进行编辑。</strong> 
	 <div class="editor edit"><?php echo form::editor($notify['code'], $template[$notify['code']]);?></div>
</div>