<ul class="web p3">
	<li> <strong>模版ID</strong>
		<input type="text" value="<?php echo $template[$notify['code']]; ?>" name="<?php echo $notify['code'] ?>" class="text_input" />
		<span>请填写微信公众账号中模板消息所对应的模板ID</span>
	</li>
</ul>