<?php 
class RegPromotionModel extends SystemModel{
	
}
