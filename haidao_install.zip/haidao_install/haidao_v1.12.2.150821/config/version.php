<?php
return array (
	'VERSION' => 'v1.12.2.150821',
	'BUILD' => '2015-08-21 15:50:51',
);