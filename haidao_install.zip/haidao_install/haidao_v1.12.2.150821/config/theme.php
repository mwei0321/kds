<?php 
return array (
  'TMPL_THEME' => 'default',
  'TAGLIB_BEGIN' => '{',
  'TAGLIB_END' => '}',
  'TAGLIB_NAME' => 'hd',
);