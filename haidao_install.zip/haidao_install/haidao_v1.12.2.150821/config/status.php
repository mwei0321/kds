<?php
return array(
	'c_order_status' => array('未确认', '已确认', '已完成', '已作废', '已取消'),
	'c_pay_status' => array('未付款', '已付款', '已退款'),
	'c_delivery_status' => array('未发货','已发货', '已退货'),
	
	'log_order_status' => array('创建订单', '确认订单', '完成订单', '订单作废', '取消订单'),
	'log_pay_status' => array('未付款', '确认付款', '订单退款'),
	'log_delivery_status' => array('未发货', '确认发货', '订单退货'),
	'log_parcel_status'=>array('待配送','配送中','配送完成'),
);