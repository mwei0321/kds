<?php
return array(
	'DB_TYPE'=>'mysql',
    /*本地 */
	'DB_HOST'=>'{DB_HOST}',
	'DB_PORT'=>'3306',
	'DB_NAME'=>'{DB_NAME}',
	'DB_USER'=>'{DB_USER}',
	'DB_PWD'=>'{DB_PWD}',
	'DB_PREFIX'=>'{DB_PREFIX}',

);