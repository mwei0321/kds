<?php
	return array(
		'PAGE_CONFIG' => array(
			//'header' => '条记录', 
			'prev' => '上一页', 
			'next' => '下一页', 
			// 'first' => '第一页', 
			// 'last' => '最后一页', 
			'theme' => '%frist% %upPage% %linkPage% %downPage% %end% 共<b>%totalPage%</b><em>页&nbsp;&nbsp;&nbsp;到第</em><input id="page_jump_num" value="" onkeydown="javascript:if(event.keyCode==13){page_jump();return false;}" class="input-txt"><em>页</em><li><a href="javascript:page_jump();" class="btn-default">确定</a></li>')
		);
