<?php 
return array (
  'kuaidi_key' => '6cb4071a68abf951',
);